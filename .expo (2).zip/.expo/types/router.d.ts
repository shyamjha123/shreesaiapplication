/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(home)` | `/(home)/Bottomnavigation` | `/(home)/Home` | `/(home)/Main` | `/(home)/Profile` | `/(tabs)` | `/(tabs)/` | `/(tabs)/AEPSWallet` | `/(tabs)/Aboutus` | `/(tabs)/Aepsreport` | `/(tabs)/Barcodescanner` | `/(tabs)/Blog` | `/(tabs)/ChangeMpin` | `/(tabs)/ChangePassword` | `/(tabs)/Contact` | `/(tabs)/Contactus` | `/(tabs)/Dashboard` | `/(tabs)/DashboardTabs` | `/(tabs)/Dmtreport` | `/(tabs)/Forgotmpin` | `/(tabs)/Forgotpassword` | `/(tabs)/Fundmanagement` | `/(tabs)/Fundrequest` | `/(tabs)/Help` | `/(tabs)/HelpReport` | `/(tabs)/Home` | `/(tabs)/Homepage` | `/(tabs)/Homescreen` | `/(tabs)/InactivityHandler` | `/(tabs)/Login` | `/(tabs)/Mainwallet` | `/(tabs)/Mpin` | `/(tabs)/Payout` | `/(tabs)/Payoutreport` | `/(tabs)/ProfileScreen` | `/(tabs)/Report` | `/(tabs)/Services` | `/(tabs)/Signup` | `/(tabs)/Splashscreen` | `/(tabs)/Topup` | `/(tabs)/Upipayment` | `/(tabs)/Upitransactionreport` | `/(tabs)/Wallet` | `/(tabs)/Zpayout` | `/(tabs)/_tablayout` | `/(tabs)/details` | `/(tabs)/dummydata/Dummydatapayout` | `/(tabs)/explore` | `/AEPSWallet` | `/Aboutus` | `/Aepsreport` | `/Barcodescanner` | `/Blog` | `/Bottomnavigation` | `/ChangeMpin` | `/ChangePassword` | `/Contact` | `/Contactus` | `/Dashboard` | `/DashboardTabs` | `/Dmtreport` | `/Forgotmpin` | `/Forgotpassword` | `/Fundmanagement` | `/Fundrequest` | `/Help` | `/HelpReport` | `/Home` | `/Homepage` | `/Homescreen` | `/InactivityHandler` | `/Login` | `/Main` | `/Mainwallet` | `/Mpin` | `/Payout` | `/Payoutreport` | `/Profile` | `/ProfileScreen` | `/Report` | `/Services` | `/Signup` | `/Splashscreen` | `/Topup` | `/Upipayment` | `/Upitransactionreport` | `/Wallet` | `/Zpayout` | `/_sitemap` | `/_tablayout` | `/common/CommonCards` | `/common/Homescreencards` | `/common/Homescreencontainer` | `/details` | `/dummydata/Dummydatapayout` | `/explore` | `/pages/Dashboard` | `/pages/Forgotpasswordmenu`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
