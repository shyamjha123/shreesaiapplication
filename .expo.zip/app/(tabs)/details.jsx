import { View, Text } from 'react-native'
import React from 'react'

const details = () => {
  return (
    <View>
      <Text>details</Text>
    </View>
  )
}

export default details