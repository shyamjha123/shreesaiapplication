
// latest 
import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet, SafeAreaView, Pressable, FlatList, ActivityIndicator } from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { format } from "date-fns";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";

const Payoutreport = () => {
    const [state, setState] = useState({
        currentPicker: null,
        isDatePickerVisible: false,
        startDate: null,
        endDate: null,
    });
    const [transactions, setTransactions] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        fetchTransactions(); // Fetch transactions on component mount
    }, []);

    const showDatePicker = (pickerType) => {
        setState((prevState) => ({
            ...prevState,
            currentPicker: pickerType,
            isDatePickerVisible: true,
        }));
    };

    const handleConfirm = (date) => {
        const formattedDate = format(date, "MM-dd-yyyy");
        setState((prevState) => ({
            ...prevState,
            isDatePickerVisible: false,
            [prevState.currentPicker === "from" ? "startDate" : "endDate"]: formattedDate,
        }));
    };

    const fetchTransactions = async () => {
        setLoading(true);
        try {
            const token = await AsyncStorage.getItem("token");
            const url = state.startDate && state.endDate
                ? `https://zevopay.online/api/v1/wallet/transactions?start_date=${state.startDate}&end_date=${state.endDate}`
                : `https://zevopay.online/api/v1/wallet/transactions`;

            const response = await fetch(url, {
                method: "GET",
                headers: {
                    Authorization: `Bearer ${token}`,
                    "Content-Type": "application/json",
                },
            });
            const jsonResponse = await response.json();

            if (jsonResponse && jsonResponse.data && Array.isArray(jsonResponse.data)) {
                const filteredData = jsonResponse.data.filter((item) => item.type === "payout");
                setTransactions(filteredData);
            } else {
                setTransactions([]);
            }
        } catch (error) {
            console.error("Error fetching transactions:", error);
        } finally {
            setLoading(false);
        }
    };

    const renderTransactionCard = ({ item }) => (
        <View style={styles.card}>
            <View>
                <Text style={styles.cardText}>Name: {item.beneficiaryName}</Text>
                <Text style={styles.cardText}>Beneficiary: {item.creditAccountNumber}</Text>
                <Text style={styles.cardText}>Amount: ₹{item.amount}</Text>
                <Text style={styles.cardText}>Surcharge: ₹{item.surchargeAmount}</Text>
                <Text
                    style={[
                        styles.cardText,
                        { color: item.status === "SUCCESS" || item.status === "REFUNDED" ? "green" : "red" }
                    ]}
                >
                    Status: {item.status}
                </Text>
                <Text style={styles.cardText}>
                    Transaction ID: {item.status === "FAILED" ? item.id : item.transactionID}
                </Text>

                <Text style={styles.cardText}>RRN NO: {item.transactionReferenceNo}</Text>
                <Text style={styles.cardText}>Date: {new Date(item.created_at).toLocaleString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                    hour: "numeric",
                    minute: "numeric",
                    hour12: true
                })}</Text>
            </View>
        </View>
    );

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.rowContainer}>
                <Pressable style={styles.dateButton} onPress={() => showDatePicker("from")}>
                    <View>
                        <View style={{ flexDirection: "row", gap: 5 }}>
                            <Text style={styles.dateText}>Date</Text>
                            <Text style={styles.dateText}>From</Text>
                        </View>
                        <Text style={styles.selectedDate}>{state.startDate || "Select"}</Text>
                    </View>
                </Pressable>

                <Pressable style={styles.dateButton} onPress={() => showDatePicker("to")}>
                    <View>

                        <View style={{ flexDirection: "row", gap: 5 }}>
                            <Text style={styles.dateText}>Date</Text>
                            <Text style={styles.dateText}>To</Text>
                        </View>

                        <Text style={styles.selectedDate}>{state.endDate || "Select"}</Text>
                    </View>
                </Pressable>
                <Pressable onPress={fetchTransactions} style={styles.findButton}>
                    <Text style={styles.findButtonText}>FIND</Text>
                </Pressable>

            </View>
            <DateTimePickerModal
                isVisible={state.isDatePickerVisible}
                mode="date"
                onConfirm={handleConfirm}
                onCancel={() => setState((prevState) => ({ ...prevState, isDatePickerVisible: false }))}
            />
            <View style={styles.cardContainer}>
                {loading ? <ActivityIndicator size="large" color="#007BB5" /> : <FlatList data={transactions} renderItem={renderTransactionCard} />}
            </View>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: "#fff", paddingTop: 30 },
    rowContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        width: "90%",
        marginBottom: 30,
    },
    dateButton: {
        backgroundColor: "rgba(211, 211, 211, 0.5)",
        width: "30%", // Reduced width for Date From/To buttons
        height: 50,
        paddingLeft: 10,
        borderRadius: 10,
        justifyContent: "center",
    },
    findButton: {
        backgroundColor: "#007BB5",
        width: "20%", // Find button smaller width
        height: 50,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 50,
    },
    findButtonText: {
        color: "#fff",
        fontWeight: "bold",
    },
    dateText: {
        color: "white",
        fontWeight: "bold",
    },
    cardContainer: { flex: 1, width: "100%", backgroundColor: "lightgray" },
    card: { backgroundColor: "white", padding: 15, margin: 10, borderRadius: 5, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, elevation: 5 },
    cardText: { color: "gray", fontSize: 16, marginBottom: 5 },
    selectedDate: { color: "gray" },
});

export default Payoutreport;








