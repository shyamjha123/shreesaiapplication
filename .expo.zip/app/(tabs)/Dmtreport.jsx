import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  Alert,
} from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons, MaterialIcons, MaterialCommunityIcons } from '@expo/vector-icons';
import { format } from "date-fns";

const Dmtreport = () => {
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [currentPicker, setCurrentPicker] = useState(null);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);

  const showDatePicker = (pickerType) => {
    setCurrentPicker(pickerType);
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = (date) => {
    const formattedDate = format(date, "MM-dd-yyyy");
    if (currentPicker === "from") {
      setStartDate(formattedDate);
    } else if (currentPicker === "to") {
      setEndDate(formattedDate);
    }
    hideDatePicker();
  };

  const fetchTransactions = async (useDateRange = false) => {
    let url = "https://zevopay.online/api/v1/wallet/transactions";

    if (useDateRange) {
      if (!startDate || !endDate) {
        Alert.alert("Error", "Please select both start and end dates.");
        return;
      }
      url += `?start_date=${startDate}&end_date=${endDate}`;
    }

    try {
      setLoading(true);
      const token = await AsyncStorage.getItem("token");
      if (!token) {
        Alert.alert("Error", "User not authenticated. Token is missing.");
        return;
      }

      const response = await fetch(url, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await response.json();
      if (response.ok) {
        // Filter out transactions with mode "UPI"
        const filteredTransactions = data.data.filter(
          (transaction) =>
            transaction.mode !== "UPI" &&
            ["CASH CREDIT", "CASH DEBIT", "NEFT", "RTGS", "IMPS"].includes(transaction.mode)
        );
        setTransactions(filteredTransactions);
      } else {
        Alert.alert("Error", data.message || "Failed to fetch transactions.");
      }
    } catch (error) {
      console.error(error);
      Alert.alert("Error", "An error occurred while fetching transactions.");
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    // Fetch data by default when the component loads
    fetchTransactions(false);
  }, []);

  const renderTransactionCard = ({ item }) => (
    <View style={{ justifyContent: "center", alignItems: "center" }}>
      <View style={styles.card}>
        <View style={{ flexDirection: "column" }}>
          <View style={{ flexDirection: "row", gap: 5 }}>
            <Ionicons
              name={"phone-portrait-outline"}
              size={25}
              color={"red"}
            />
            <Text style={{ color: "gray" }}>6204132195</Text>
          </View>
          <View style={{ flexDirection: "row", gap: 5 }}>
            <MaterialIcons name="contact-page" size={25} color="skyblue" />
            <Text style={styles.cardText}>{item.user.name} </Text>
          </View>
          <View style={{ flexDirection: "row", gap: 5 }}>
            <MaterialCommunityIcons name="bank" size={25} color="#007BB5" />
            <Text style={styles.cardText}>{item.van}</Text>
          </View>

          <Text style={styles.cardText}>₹ {item.tranAmt}</Text>
          <Text style={styles.cardText}>Txn Id: {item.utr}</Text>
          <Text style={styles.carddate}>
            {new Date(item.updated_at).toLocaleString("en-US", {
              month: "long",
              day: "numeric",
              year: "numeric",
              hour: "numeric",
              minute: "numeric",
              hour12: true,
            })}
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>

      <View style={styles.rowContainer}>
        <Pressable
          style={styles.dateButton}
          onPress={() => showDatePicker("from")}
        >
          <View>
            <View style={{ flexDirection: "row", gap: 5 }}>
              <Text style={styles.dateText}>Date</Text>
              <Text style={styles.dateText}>From</Text>
            </View>
            <Text style={styles.selectedDate}>{startDate || "Select"}</Text>
          </View>
        </Pressable>

        <Pressable
          style={styles.dateButton}
          onPress={() => showDatePicker("to")}
        >
          <View>
            <View style={{ flexDirection: "row", gap: 5 }}>
              <Text style={styles.dateText}>Date</Text>
              <Text style={styles.dateText}>To</Text>
            </View>
            <Text style={styles.selectedDate}>{endDate || "Select"}</Text>
          </View>
        </Pressable>
        <Pressable
          style={styles.findButton}
          onPress={() => fetchTransactions(true)}
        >
          <Text style={styles.findButtonText}>FIND</Text>
        </Pressable>
      </View>

      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />

      <View style={styles.cardContainer}>

        <FlatList
          data={transactions}
          keyExtractor={(item) => item.id.toString()}
          renderItem={renderTransactionCard}
          contentContainerStyle={styles.listContainer}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 30,
    alignItems: "center",
  },
  cardContainer: {
    flex: 1,
    width: "100%",
    backgroundColor: "lightgray"
  },
  rowContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "90%",
    marginBottom: 30,
  },
  dateButton: {
    backgroundColor: "rgba(211, 211, 211, 0.5)",
    width: "30%",
    height: 50,
    paddingLeft: 10,
    borderRadius: 10,
    justifyContent: "center",
  },
  dateText: {
    color: "white",
    fontWeight: "bold",
  },
  selectedDate: {
    color: "gray",
    marginTop: 5,
  },
  findButton: {
    backgroundColor: "#007BB5",
    width: "20%",
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 50,
  },
  findButtonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  listContainer: {
    paddingTop: 20,
  },
  card: {
    flexDirection: "row",
    marginLeft: 20,
    width: "90%",
    backgroundColor: "white",
    padding: 15,
    marginVertical: 10,
    borderRadius: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  cardText: {
    color: "gray",
    fontSize: 16,
    marginBottom: 5,
  },
  carddate: {
    color: "gray",
    fontSize: 16,
  },
});

export default Dmtreport;
