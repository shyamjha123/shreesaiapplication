import { View, Text } from 'react-native'
import React from 'react'

const Bottomnavigation = () => {
  return (
    <View>
      <Text>Bottomnavigation</Text>
    </View>
  )
}

export default Bottomnavigation